import IssuesList from "./IssuesList"
import IssueDetails from "./IssueDetails"

export {
    IssuesList,
    IssueDetails
}
